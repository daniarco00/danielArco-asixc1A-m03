
#This is a commnent
print("Hello world :) ")

"""
Danil Arco Guasch
18/09/2023
ASIXc A M03 UF1 A1
Descripció: 
Estructura d'un programa informàtic -  Algoritmes - Git
...
...
"""


